package com.pc.mes.management;

public interface UserRepository {
    User findByUserId(String userId);
    
    // 메서드 추가 가능
}
