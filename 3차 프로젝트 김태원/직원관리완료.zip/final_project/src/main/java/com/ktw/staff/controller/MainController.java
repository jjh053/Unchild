package com.ktw.staff.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
	
	@RequestMapping("/main")
	public String mainForm(Model model) {
		model.addAttribute("음..", "왜이럼");
		System.out.println("왔냐고");
		
		return "main";
	}
	
	@RequestMapping("/mypage")
	public String myPageForm() {
		return "mypage";
	}
	
}
