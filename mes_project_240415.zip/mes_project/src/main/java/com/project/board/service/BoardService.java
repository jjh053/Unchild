package com.project.board.service;

import java.util.List;

import com.project.board.dto.BoardDTO;

public interface BoardService {
	public List<BoardDTO> listBoard();
}
