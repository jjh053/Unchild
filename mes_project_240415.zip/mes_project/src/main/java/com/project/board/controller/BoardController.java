package com.project.board.controller;

import org.springframework.ui.Model;

public interface BoardController {
	public String viewBoardList(Model model);
}
