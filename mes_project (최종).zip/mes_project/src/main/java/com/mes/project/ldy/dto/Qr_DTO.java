package com.mes.project.ldy.dto;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class Qr_DTO {
	String fileName;
	String data;
}
