package com.mes.project.lsh.workReport;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WorkReportService {

	@Autowired
	private WorkReportDAO workReportDAO;
	
	// 조회
	public Map<String, Object> selectService() {
		
		Map<String, Object> map = new HashMap<String, Object>();
		List<WorkReportDTO> list = workReportDAO.selectWorkReport();	

		map.put("list", list);
		map.put("PagingDTO", workReportDAO.selectPageNum());
		
		return map;
	}
}
