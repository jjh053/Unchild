package Login;

import java.util.ArrayList;
import java.util.List;

class UserManager {
    private List<User> users = new ArrayList<>();
    
    public UserManager() {
//    	2차원 List 아이디와 패스워드 저장
        users.add(new User("user123", "pass742"));
        users.add(new User("admin", "pass891"));
    }
    
    // 회원 추가 메서드
    public void addUser(String id, String password) {
        users.add(new User(id, password));
    }
    
    // 아이디 중복체크 메서드
    public boolean isIdDuplicate(String id) {
//    	순차 비교
        for (User user : users) {
            if (user.getId().equals(id)) {
                return true;
            }
        }
        return false;
    }
//  list getter
    public List<User> getUsers() {
        return users;
    }
}