package Login;

class LoginService {
    private boolean cheak = false;
    
//    아이디 비밀번호 체크
    public boolean doLogin(String inputId, String inputPw, UserManager userManager) {
        for (User user : userManager.getUsers()) {
            if (user.getId().equals(inputId) && user.getPassword().equals(inputPw)) {
                setCheak(true);
                return true;
            }
        }
//        기본값: false 굳이 안해도 else 처리 가능
        setCheak(false);
        System.err.println("잘못된 아이디나 비밀번호입니다.");
        return false;
    }
    
//    중복 체크 세터
    public void setCheak(boolean cheak) {
        this.cheak = cheak;
    }
    
//    중복 체크 게터
    public boolean isCheak() {
        return cheak;
    }
}