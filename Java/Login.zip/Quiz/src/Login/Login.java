package Login;

public class Login {
	
//	메인 실행 메서드
    public static void main(String[] args) {
//    	회원 추가밑 관리
        UserManager userManager = new UserManager();
//      로그인 중복체크
        LoginService loginService = new LoginService();
//      로그인 인터페이스 
        LoginInterface loginInterface = new LoginInterface(loginService, userManager);
//      메뉴 호출
        loginInterface.showMenu();
    }
}
