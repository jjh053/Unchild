package Login;

class User {
    private String id;
    private String password;
    
//    유저 정보
    public User(String id, String password) {
        this.id = id;
        this.password = password;
    }
//    유저 게터
    public String getId() {
        return id;
    }
    
//    유저 세터
    public String getPassword() {
        return password;
    }
}
