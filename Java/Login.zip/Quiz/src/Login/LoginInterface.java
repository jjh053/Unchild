package Login;

import java.util.Scanner;

class LoginInterface {
   private LoginService loginService;
   private UserManager userManager;
   
//   로그인 인터페이스 메서드
   public LoginInterface(LoginService loginService, UserManager userManager) {
      this.loginService = loginService;
      this.userManager = userManager;
   }

//   메뉴 출력 스캐너 사용
   public void showMenu() {
      Scanner scan = new Scanner(System.in);
      while (true) {
         System.out.println("\n====로그인 폼====");
         System.out.println("1. 로그인");
         System.out.println("2. 회원가입");
         System.out.println("3. 종료");

         System.out.println("메뉴를 선택하세요(숫자 입력):");
         int choice = scan.nextInt();
         scan.nextLine();
         
//         1. 로그인 2. 회원가입 3. 종료
         switch (choice) {
         case 1:
            doLogin();
            break;
         case 2:
            doJoin();
            break;
         case 3:
            System.out.println("프로그램을 종료합니다.");
            scan.close();
            System.exit(0);
            break;
         default:
            System.err.println("잘못된 입력입니다. 다시 선택하세요.");
         }
      }
   }
   
//   로그인 메서드
   private void doLogin() {
      Scanner scan = new Scanner(System.in);

      System.out.println("아이디를 입력하세요.");
      String inputId = scan.nextLine();

      System.out.println("비밀번호를 입력하세요.");
      String inputPw = scan.nextLine();

      if (loginService.doLogin(inputId, inputPw, userManager)) {
         System.out.println("로그인 성공!");
         if ("admin".equals(inputId)) {
            System.out.println("관리자 페이지 입니다.");
         } else {
            System.out.println("환영합니다. " + inputId + "님");
         }
         System.exit(0);
      }
   }
   
// 회원가입 메서드
   private void doJoin() {
      Scanner scan = new Scanner(System.in);
      System.out.println("회원가입을 시작합니다.");
      System.out.println("새로운 아이디를 입력하세요:");
      String newId = scan.nextLine();
      
//      중복 체크
      if (userManager.isIdDuplicate(newId)) {
         System.err.println("이미 존재하는 아이디입니다. 다른 아이디를 선택하세요.");
         return;
      }

      System.out.println("새로운 비밀번호를 입력하세요:");
      String newPw = scan.nextLine();
      
//     2차원 배열에 ID,Pass 추가
      userManager.addUser(newId, newPw);

      System.out.println("회원가입 되었습니다");
   }
}