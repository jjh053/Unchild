package com.pc.emp.dto;

public class Main_DTO {
	int mesid;
	String 품목명;
	String 품목;
	String 물품설명1;
	String 물품설명2;
	int 양품수량;
	String 양품재고위치;
	int 불량수량;
	int 가격;
	String 불량재고위치;
	
	int 일일번호;
	String 일일등급;
	String 일일완제품;
	String 일일불량품;
	
	
	
	int 월간번호;
	String 월간등급;
	String 월간완제품;
	String 월간불량품;
	
	
	
	public int get일일번호() {
		return 일일번호;
	}

	public void set일일번호(int 일일번호) {
		this.일일번호 = 일일번호;
	}

	public String get일일등급() {
		return 일일등급;
	}

	public void set일일등급(String 일일등급) {
		this.일일등급 = 일일등급;
	}

	public String get일일완제품() {
		return 일일완제품;
	}

	public void set일일완제품(String 일일완제품) {
		this.일일완제품 = 일일완제품;
	}

	public String get일일불량품() {
		return 일일불량품;
	}

	public void set일일불량품(String 일일불량품) {
		this.일일불량품 = 일일불량품;
	}



	
	
	public int get월간번호() {
		return 월간번호;
	}

	public void set월간번호(int 월간번호) {
		this.월간번호 = 월간번호;
	}

	public String get월간등급() {
		return 월간등급;
	}

	public void set월간등급(String 월간등급) {
		this.월간등급 = 월간등급;
	}

	public String get월간완제품() {
		return 월간완제품;
	}

	public void set월간완제품(String 월간완제품) {
		this.월간완제품 = 월간완제품;
	}

	public String get월간불량품() {
		return 월간불량품;
	}

	public void set월간불량품(String 월간불량품) {
		this.월간불량품 = 월간불량품;
	}

	
	
	
	
	
	public String get품목명() {
		return 품목명;
	}
	
	public void set품목명(String 품목명) {
		this.품목명 = 품목명;
	}
	
	public int get가격() {
		return 가격;
	}

	public void set가격(int 가격) {
		this.가격 = 가격;
	}


	public int getMesid() {
		return mesid;
	}

	public void setMesid(int mesid) {
		this.mesid = mesid;
	}

	public String get물품설명1() {
		return 물품설명1;
	}

	public void set물품설명1(String 물품설명1) {
		this.물품설명1 = 물품설명1;
	}

	public String get물품설명2() {
		return 물품설명2;
	}

	public void set물품설명2(String 물품설명2) {
		this.물품설명2 = 물품설명2;
	}

	public String get품목() {
		return 품목;
	}

	public void set품목(String 품목) {
		this.품목 = 품목;
	}

	public int get양품수량() {
		return 양품수량;
	}

	public void set양품수량(int 양품수량) {
		this.양품수량 = 양품수량;
	}

	public String get양품재고위치() {
		return 양품재고위치;
	}

	public void set양품재고위치(String 양품재고위치) {
		this.양품재고위치 = 양품재고위치;
	}

	public int get불량수량() {
		return 불량수량;
	}

	public void set불량수량(int 불량수량) {
		this.불량수량 = 불량수량;
	}

	public String get불량재고위치() {
		return 불량재고위치;
	}

	public void set불량재고위치(String 불량재고위치) {
		this.불량재고위치 = 불량재고위치;
	}

}
