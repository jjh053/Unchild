package com.pc.emp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.pc.emp.dto.WorkOrderDTO;

public class WorkOrderDAO {

	public List selectTable(String local) {
		List list = new ArrayList();
		
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@112.148.46.134:51521:xe";		
		String user = "unchild";
		String password = "mesteam";
		
		try {
			Class.forName(driver);
			
			Connection con = DriverManager.getConnection(url, user, password);
			
			String query = "";
			
			if( local.equals("/workOrder") ) {
				
				query += " SELECT"
						+ " w_bord_seq, w_title, w_detail, w_imgUrl";
				query += " FROM"
						+ " workBord";
				query += " WHERE"
						+ " w_type = 1";
			} else if( local.equals("/workSafety") ) {
				
				query += " SELECT"
						+ " w_bord_seq, w_title, w_detail, w_imgUrl";
				query += " FROM"
						+ " workBord";
				query += " WHERE"
						+ " w_type = 2";
			} else if( local.equals("/workQuality") ) {
				
				query += " SELECT"
						+ " w_bord_seq, w_title, w_detail, w_imgUrl";
				query += " FROM"
						+ " workBord";
				query += " WHERE"
						+ " w_type = 3"
						+ " OR"
						+ " w_bord_seq = 13";
			} else if( local.equals("/workReport") ) {
				
//				query += " SELECT"
//						+ " "
			}
			
			PreparedStatement ps = con.prepareStatement(query);
			
			ResultSet rs = ps.executeQuery();
			
			while( rs.next() ) {
				
				int seq = rs.getInt(1);
				String title = rs.getString(2);
				String detail = rs.getString(3);
				String urlImage = rs.getString(4);
				
				WorkOrderDTO dto = new WorkOrderDTO();
				dto.setSeq(seq);
				dto.setTitle(title);
				dto.setDetail(detail);
				dto.setUrlImage(urlImage);
				
				list.add(dto);
			}
			
			rs.close();
			ps.close();	
			
			if( local.equals("/workQuality") ) {
				
				query = "";
				query += " SELECT"
						+ " procId, lineNum, endtime, pass, g_sequence";
				query += " FROM"
						+ " testh";
				query += " WHERE"
						+ " qualitychk = 0";
				
				PreparedStatement ps2 = con.prepareStatement(query);
				ResultSet rs2 = ps2.executeQuery();
				 
				 while( rs2.next() ) {
					 
					 int goodsSeq = rs2.getInt("procId");
					 String line = rs2.getString("lineNum");
					 Date date = rs2.getDate("endtime");
					 int quantity = rs2.getInt("pass");
					 int model = rs2.getInt("g_sequence");
					 
					 // Date 타입을 문자열로 변환
					 SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					 String hireDate = format.format(date);
					 System.out.println("line" + line);
					 WorkOrderDTO dto = new WorkOrderDTO();
					 dto.setGoodsSeq(goodsSeq);
					 dto.setLine(line);
					 dto.setModel(model);
					 dto.setHireDate(hireDate);
					 dto.setQuantity(quantity);
					 list.add(dto);
				 }
				 
				rs2.close();
				ps2.close();
				
				query = "";
				query += " SELECT"
						+ " staffno, sname, sphone, smail";
				query += " FROM"
						+ " staff";
				query += " WHERE"
						+ " staffno = 3000";
						
				PreparedStatement ps3 = con.prepareStatement(query);
				ResultSet rs3 = ps3.executeQuery();
					 
				if ( rs3.next() ) {
					
					int workerId = rs3.getInt(1);
					String workerName = rs3.getString(2);
					String workerTel = rs3.getString(3);
					String workerEmail = rs3.getString(4);
					
					WorkOrderDTO dto = new WorkOrderDTO();
					dto.setWorkerId(workerId);
					dto.setWorkerName(workerName);
					dto.setWorkerTel(workerTel);
					dto.setWorkerEmail(workerEmail);
					list.add(dto);
				}
				 
				rs3.close();
				ps3.close();
			}
			
			
				
			con.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	public void insertInfo(WorkOrderDTO dto, String local) {
	    String driver = "oracle.jdbc.driver.OracleDriver";
	    String url = "jdbc:oracle:thin:@112.148.46.134:51521:xe";
	    String user = "unchild";
	    String password = "mesteam";

	    try {
	        Class.forName(driver);

	        Connection con = DriverManager.getConnection(url, user, password);

	        String title = dto.getTitle();
	        String detail = dto.getDetail();
	        String urlImage = dto.getUrlImage();

	        // Replace newline characters based on the local context
	        if (local.equals("/workOrder")) {
	            detail = detail.replace(System.lineSeparator(), "\\n");
	        } else if (local.equals("/workSafety") || local.equals("/workQuality")) {
	            detail = "- " + detail.replace(System.lineSeparator(), "\\n- ");
	        }

	        String query = "";

	        if (local.equals("/workOrder") || local.equals("/workSafety")) {
	            // Insert into workbord table for workOrder and workSafety
	            query += "INSERT INTO workbord(w_bord_seq, w_title, w_detail, w_imgUrl, w_type)";
	            query += " VALUES (w_bord_seq.NEXTVAL, ?, ?, ?, ?)";

	            PreparedStatement ps = con.prepareStatement(query);
	            ps.setString(1, title);
	            ps.setString(2, detail);
	            ps.setString(3, urlImage);
	            ps.setInt(4, local.equals("/workOrder") ? 1 : 2);
	            ps.executeUpdate();
	            ps.close();
	        } else if (local.equals("/workQuality")) {
	            int facilitySeq = dto.getFacilitySeq();
	            String facilityDetail = dto.getFacilityDetail();
	            String sendTime = dto.getSendTime();
	            int workerId = dto.getWorkerId();
	            int unclear = dto.getUnclear();

	            int defective;

	            // Update equipment to mark qualitychk as 1
	            query = "UPDATE equipment SET qualitychk = 1 WHERE procid = ?";
	            PreparedStatement ps = con.prepareStatement(query);
	            ps.setInt(1, facilitySeq);
	            ps.executeUpdate();
	            ps.close();

	            // Check if facilityDetail is empty
	            if (facilityDetail.equals("")) {
	                defective = 0;
	            } else {
	                defective = 1;

	                // Retrieve quantity from testh table
	                query = "SELECT pass FROM testh WHERE g_sequence = ?";
	                PreparedStatement ps2 = con.prepareStatement(query);
	                ps2.setInt(1, facilitySeq);
	                ResultSet rs2 = ps2.executeQuery();

	                int quantity = 0;
	                int clear_num = 0;

	                if (rs2.next()) {
	                    quantity = rs2.getInt("pass");
	                    clear_num = quantity - unclear;
	                }

	                ps2.close();

	                // Insert into work table
	                query = "INSERT INTO work(w_seq, procid, w_bord_seq, unclear_num, status, staffno, end_time) " +
	                        "VALUES (w_SEQ.NEXTVAL, ?, ?, ?, ?, ?, TO_DATE(?, 'YYYY-MM-DD HH24:MI'))";
	                PreparedStatement ps3 = con.prepareStatement(query);
	                ps3.setInt(1, facilitySeq);
	                ps3.setString(2, facilityDetail);
	                ps3.setInt(3, clear_num);
	                ps3.setInt(4, unclear);
	                ps3.setInt(5, defective);
	                ps3.setInt(6, workerId);
	                ps3.setString(7, sendTime);
	                ps3.executeUpdate();
	                ps3.close();
	            }
	        }

	        con.close();

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	public void deleteColumn(WorkOrderDTO dto) {
		
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@112.148.46.134:51521:xe";		
		String user = "unchild";
		String password = "mesteam";
		
		try {
			
			Class.forName(driver);
			
			Connection con = DriverManager.getConnection(url, user, password);
			
			int seq = dto.getSeq();
			
			String query = "";

			query += " DELETE FROM"
					+ " workbord";
			query += " WHERE"
					+ " w_bord_seq =";
			query += seq;
			
			PreparedStatement ps = con.prepareStatement(query);
			ps.executeQuery();

			ps.close();
			con.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void retouchColumn(WorkOrderDTO dto, String local) {
		
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@112.148.46.134:51521:xe";		
		String user = "unchild";
		String password = "mesteam";
		
		try {
			
			Class.forName(driver);
			
			Connection con = DriverManager.getConnection(url, user, password);
			
			int seq = dto.getSeq();
			String title = dto.getTitle();
			String detail = dto.getDetail();
			String urlImage = dto.getUrlImage();
			
			int facilitySeq = dto.getFacilitySeq();
			String facilityDetail = dto.getFacilityDetail();
			String sendTime = dto.getSendTime();
			int workerId = dto.getWorkerId();
			int unclear = dto.getUnclear();
			
			String query = "";
			
			if( local.equals("/workOrderRetouch") || local.equals("/workSafetyRetouch") ) {
				
				query += " UPDATE"
						+ " workbord";
				query += " SET"
						+ " w_title = '"
						+ title
						+ "',"
						+ " w_detail = '"
						+ detail
						+ "',"
						+ " w_imgUrl = '"
						+ urlImage
						+ "'";
				query += " WHERE"
						+ " w_bord_seq = "
						+ seq;
			} 
//			else if( local.equals("/facilityUpdate") ) {
//				
//				query += " UPDATE"
//						+ " equipment";
//				query += " SET"
//						+ " qualitychk = 1";
//				query += " WHERE"
//						+ " procid = "
//						+ facilitySeq;				
//				
//			}
						
			
			PreparedStatement ps = con.prepareStatement(query);
			ps.executeQuery();
			ps.close();
			
//			if( local.equals("/facilityUpdate") ) {
//				
//				int defective;    
//				if(facilityDetail.equals("")) {
//					
//					defective = 0;
//				} else {
//					
//					defective = 1;
//				}
//				
//				query = "";
//				query += " SELECT"
//						+ " pass";
//				query += " FROM"
//						+ " testh";
//				query += " WHERE"
//						+ " g_sequence = "
//						+ facilitySeq;
//				
//				PreparedStatement ps2 = con.prepareStatement(query);
//				ResultSet rs2 = ps2.executeQuery();
//				
//				ps2.executeQuery();
//				ps2.close();
//				
//				int quantity = rs2.getInt("pass");
//				int clear_num = quantity - unclear;
//				
//				query = "";
//				query += " INSERT INTO"
//						+ " work(w_seq, procid, w_bord_seq, unclear_num, status, staffno, end_time)";
//				query += " VALUES"
//						+ " ("
//						+ " w_SEQ.NEXTVAL, "
//						+ facilitySeq
//						+ ",'"
//						+ facilityDetail
//						+ "',"
//						+ clear_num
//						+ "',"
//						+ unclear
//						+ ","
//						+ defective
//						+ ","
//						+ workerId
//						+ ", TO_DATE('"
//						+ sendTime 
//						+ "', 'YYYY-MM-DD HH24:MI')";
//				
//				PreparedStatement ps3 = con.prepareStatement(query);
//				ps3.close();
//			}
			
			con.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
