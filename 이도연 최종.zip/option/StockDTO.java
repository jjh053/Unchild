package option;

public class StockDTO {
	int stockNum;
	String stockName;
	int stockCount;
	String stockID;
	
	
	public int getStockNum() {
		return stockNum;
	}

	public void setStockNum(int stockNum) {
		this.stockNum = stockNum;
	}

	public String getStockName() {
		return stockName;
	}
	
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	
	public int getStockCount() {
		return stockCount;
	}
	
	public void setStockCount(int stockCount) {
		this.stockCount = stockCount;
	}
	
	public String getStockID() {
		return stockID;
	}
	
	public void setStockID(String stockID) {
		this.stockID = stockID;
	}
	
}
