package com.project.board.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import com.project.board.dto.BoardDTO;


public class BoardDAOImpl implements BoardDAO{
	
	@Autowired
	private SqlSession sess;
	
	public List<BoardDTO> selectBoard() {
		List<BoardDTO> list = sess.selectList("mapper.board.selectBoard");
		
		return list;
	}
}
