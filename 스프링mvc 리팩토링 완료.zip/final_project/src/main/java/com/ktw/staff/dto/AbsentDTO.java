package com.ktw.staff.dto;

import java.sql.Date;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;

@Component
public class AbsentDTO {
	int staffno;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	Date start_date;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	Date end_date;
	
	String reason;
	String status;
	int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getStaffno() {
		return staffno;
	}

	public void setStaffno(int staffno) {
		this.staffno = staffno;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
