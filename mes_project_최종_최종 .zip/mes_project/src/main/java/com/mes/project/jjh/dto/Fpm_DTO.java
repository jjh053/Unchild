package com.mes.project.jjh.dto;

import lombok.Data;

@Data
public class Fpm_DTO {
	
	int dayNum;
	String dayRank;
	int dayClear;
	int dayUnClear;
	
	int weekNum;
	String weekRank;
	int weekClear;
	int weekUnClear;
	
	int monthNum;
	String monthRank;
	int monthClear;
	int monthUnClear;
	
	int entryMonthSals;
	int mainMonthSals;
	int perforMonthSals;
	
	
}
