package com.mes.project.jjh.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mes.project.jjh.dto.Fpm_DTO;
import com.mes.project.jjh.service.Fpm_Service;

@Controller
public class Fpm_Controller {
	private static final Logger logger = LoggerFactory.getLogger(Fpm_Controller.class);

	@Autowired
	Fpm_Service rodiService;

	@RequestMapping("/fs")
	public String select(@ModelAttribute Fpm_DTO fpmDTO, Model model) {
		System.out.println("갈 때 Fpm_Controller fpmDTO : " + fpmDTO);
		List list = rodiService.select1(fpmDTO);
		List list2 = rodiService.select2(fpmDTO);
		List list3 = rodiService.select3(fpmDTO);
		List list4 = rodiService.select4(fpmDTO);
		
		List monthList1 = rodiService.monthSelect1(fpmDTO);
		List monthList2 = rodiService.monthSelect2(fpmDTO);
		List monthList3 = rodiService.monthSelect3(fpmDTO);
		List monthList4 = rodiService.monthSelect4(fpmDTO);
		
		List monthSalsList1 = rodiService.monthSalsList1(fpmDTO);
		List monthSalsList2 = rodiService.monthSalsList2(fpmDTO);
		List monthSalsList3 = rodiService.monthSalsList3(fpmDTO);
		List monthSalsList4 = rodiService.monthSalsList4(fpmDTO);
		
//		System.out.println("Fpm_Controller monthSalsList1 : " + monthSalsList1);
//		System.out.println("Fpm_Controller list2 : " + list2);
//		System.out.println("Fpm_Controller list3 : " + list3);
//		System.out.println("Fpm_Controller list4 : " + list4);

		model.addAttribute("list", list);
		model.addAttribute("list2", list2);
		model.addAttribute("list3", list3);
		model.addAttribute("list4", list4);
		
		model.addAttribute("monthList1", monthList1);
		model.addAttribute("monthList2", monthList2);
		model.addAttribute("monthList3", monthList3);
		model.addAttribute("monthList4", monthList4);
		
		model.addAttribute("monthSalsList1", monthSalsList1);
		model.addAttribute("monthSalsList2", monthSalsList2);
		model.addAttribute("monthSalsList3", monthSalsList3);
		model.addAttribute("monthSalsList4", monthSalsList4);
		
		return "Finished_product_management";
	}


}
