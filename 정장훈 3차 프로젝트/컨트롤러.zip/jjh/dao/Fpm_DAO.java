package com.mes.project.jjh.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mes.project.jjh.dto.Fpm_DTO;

@Repository
public class Fpm_DAO {

	@Autowired
	private SqlSession sqlSession;

	// - 작업자 - 품목선택페이지 셀렉트
	public List select1(Fpm_DTO fpm_DTO) {
		System.out.println("갈 때 select1 fpm_DAO : " + fpm_DTO);
		List result = sqlSession.selectList("mapper.fpm.selectfpm1", fpm_DTO);
		System.out.println("올 때 select1 fpm_DAO: " + result);
		return result;
	}
	public List select2(Fpm_DTO fpm_DTO) {
		System.out.println("갈 때 select2 fpm_DAO : " + fpm_DTO);
		List result = sqlSession.selectList("mapper.fpm.selectfpm2", fpm_DTO);
		System.out.println("올 때 select2 fpm_DAO: " + result);
		return result;
	}
	public List select3(Fpm_DTO fpm_DTO) {
		System.out.println("갈 때 select3 fpm_DAO : " + fpm_DTO);
		List result = sqlSession.selectList("mapper.fpm.selectfpm3", fpm_DTO);
		System.out.println("올 때 select3 fpm_DAO: " + result);
		return result;
	}
	public List select4(Fpm_DTO fpm_DTO) {
		System.out.println("갈 때 select4 fpm_DAO : " + fpm_DTO);
		List result = sqlSession.selectList("mapper.fpm.selectfpm4", fpm_DTO);
		System.out.println("올 때 select4 fpm_DAO: " + result);
		return result;
	}
	
	public List monthSelect1(Fpm_DTO fpm_DTO) {
		System.out.println("갈 때 monthSelect1 fpm_DAO : " + fpm_DTO);
		List result = sqlSession.selectList("mapper.fpm.monthSelect1", fpm_DTO);
		System.out.println("올 때 monthSelect1 fpm_DAO: " + result);
		return result;
	}
	public List monthSelect2(Fpm_DTO fpm_DTO) {
		System.out.println("갈 때 monthSelect2 fpm_DAO : " + fpm_DTO);
		List result = sqlSession.selectList("mapper.fpm.monthSelect2", fpm_DTO);
		System.out.println("올 때 monthSelect2 fpm_DAO: " + result);
		return result;
	}
	public List monthSelect3(Fpm_DTO fpm_DTO) {
		System.out.println("갈 때 monthSelect3 fpm_DAO : " + fpm_DTO);
		List result = sqlSession.selectList("mapper.fpm.monthSelect3", fpm_DTO);
		System.out.println("올 때 monthSelect3 fpm_DAO: " + result);
		return result;
	}
	public List monthSelect4(Fpm_DTO fpm_DTO) {
		System.out.println("갈 때 monthSelect4 fpm_DAO : " + fpm_DTO);
		List result = sqlSession.selectList("mapper.fpm.monthSelect4", fpm_DTO);
		System.out.println("올 때 monthSelect4 fpm_DAO: " + result);
		return result;
	}
	
	public List monthSalsList1(Fpm_DTO fpm_DTO) {
		System.out.println("갈 때 monthSalsList1 fpm_DAO : " + fpm_DTO);
		List result = sqlSession.selectList("mapper.fpm.monthSalsList1", fpm_DTO);
		System.out.println("올 때 monthSalsList1 fpm_DAO: " + result);
		return result;
	}
	public List monthSalsList2(Fpm_DTO fpm_DTO) {
		System.out.println("갈 때 monthSalsList1 fpm_DAO : " + fpm_DTO);
		List result = sqlSession.selectList("mapper.fpm.monthSalsList2", fpm_DTO);
		System.out.println("올 때 monthSalsList1 fpm_DAO: " + result);
		return result;
	}
	public List monthSalsList3(Fpm_DTO fpm_DTO) {
		System.out.println("갈 때 monthSalsList2 fpm_DAO : " + fpm_DTO);
		List result = sqlSession.selectList("mapper.fpm.monthSalsList3", fpm_DTO);
		System.out.println("올 때 monthSalsList2 fpm_DAO: " + result);
		return result;
	}
	public List monthSalsList4(Fpm_DTO fpm_DTO) {
		System.out.println("갈 때 monthSalsList4 fpm_DAO : " + fpm_DTO);
		List result = sqlSession.selectList("mapper.fpm.monthSalsList4", fpm_DTO);
		System.out.println("올 때 monthSalsList4 fpm_DAO: " + result);
		return result;
	}
	
	
}
