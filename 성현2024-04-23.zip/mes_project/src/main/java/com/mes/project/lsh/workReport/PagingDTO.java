package com.mes.project.lsh.workReport;

public class PagingDTO {

	int page_num;

	public int getPage_num() {
		return page_num;
	}
	
	public void setPage_num(int page_num) {
		this.page_num = page_num;
	}
}
