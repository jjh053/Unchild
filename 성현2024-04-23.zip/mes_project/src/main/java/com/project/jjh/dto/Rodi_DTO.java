package com.project.jjh.dto;

public class Rodi_DTO {
	
	int mesId;
	String mesName;
	String mesGrade;
	String mesContent;
	int mesPrice;
	int gCount;
	String gLoc;
	int bCount;
	String bLoc;
	
	int de_number;
	int s_number;
	int co_number;
	String de_date;
	String de_content;
	String de_result;
	String  de_etc;
	
	
	
	public int getDe_number() {
		return de_number;
	}
	public void setDe_number(int de_number) {
		this.de_number = de_number;
	}
	public int getS_number() {
		return s_number;
	}
	public void setS_number(int s_number) {
		this.s_number = s_number;
	}
	public int getCo_number() {
		return co_number;
	}
	public void setCo_number(int co_number) {
		this.co_number = co_number;
	}
	public String getDe_date() {
		return de_date;
	}
	public void setDe_date(String de_date) {
		this.de_date = de_date;
	}
	public String getDe_content() {
		return de_content;
	}
	public void setDe_content(String de_content) {
		this.de_content = de_content;
	}
	public String getDe_result() {
		return de_result;
	}
	public void setDe_result(String de_result) {
		this.de_result = de_result;
	}
	public String getDe_etc() {
		return de_etc;
	}
	public void setDe_etc(String de_etc) {
		this.de_etc = de_etc;
	}
	public int getMesId() {
		return mesId;
	}
	public void setMesId(int mesId) {
		this.mesId = mesId;
	}
	public String getMesName() {
		return mesName;
	}
	public void setMesName(String mesName) {
		this.mesName = mesName;
	}
	public String getMesGrade() {
		return mesGrade;
	}
	public void setMesGrade(String mesGrade) {
		this.mesGrade = mesGrade;
	}
	public String getMesContent() {
		return mesContent;
	}
	public void setMesContent(String mesContent) {
		this.mesContent = mesContent;
	}
	public int getMesPrice() {
		return mesPrice;
	}
	public void setMesPrice(int mesPrice) {
		this.mesPrice = mesPrice;
	}
	public int getGCount() {
		return gCount;
	}
	public void setGCount(int gCount) {
		this.gCount = gCount;
	}
	public String getGLoc() {
		return gLoc;
	}
	public void setGLoc(String gLoc) {
		this.gLoc = gLoc;
	}
	public int getBCount() {
		return bCount;
	}
	public void setBCount(int bCount) {
		this.bCount = bCount;
	}
	public String getBLoc() {
		return bLoc;
	}
	public void setBLoc(String bLoc) {
		this.bLoc = bLoc;
	}
	
	
	
	
	
	
	
	
	
	int mesid;
	String 품목;
	String 물품설명1;
	String 물품설명2;
	int 양품수량;
	String 양품재고위치;
	int 불량수량;
	String 불량재고위치;
	
	String 재고신청내역;
	int 수량;
	
	String 불량재고신청내역;
	int 불량신청수량;
	
	String 불량사유;
	String 기타입력사항;

	
	public String get불량사유() {
		return 불량사유;
	}

	public void set불량사유(String 불량사유) {
		this.불량사유 = 불량사유;
	}

	public String get기타입력사항() {
		return 기타입력사항;
	}

	public void set기타입력사항(String 기타입력사항) {
		this.기타입력사항 = 기타입력사항;
	}


	
	public String get불량재고신청내역() {
		return 불량재고신청내역;
	}

	public void set불량재고신청내역(String 불량재고신청내역) {
		this.불량재고신청내역 = 불량재고신청내역;
	}

	public int get불량신청수량() {
		return 불량신청수량;
	}

	public void set불량신청수량(int 불량신청수량) {
		this.불량신청수량 = 불량신청수량;
	}

	public String get재고신청내역() {
		return 재고신청내역;
	}

	public void set재고신청내역(String 재고신청내역) {
		this.재고신청내역 = 재고신청내역;
	}

	public int get수량() {
		return 수량;
	}

	public void set수량(int 수량) {
		this.수량 = 수량;
	}

	public int getMesid() {
		return mesid;
	}

	public void setMesid(int mesid) {
		this.mesid = mesid;
	}

	public String get물품설명1() {
		return 물품설명1;
	}

	public void set물품설명1(String 물품설명1) {
		this.물품설명1 = 물품설명1;
	}

	public String get물품설명2() {
		return 물품설명2;
	}

	public void set물품설명2(String 물품설명2) {
		this.물품설명2 = 물품설명2;
	}

	public String get품목() {
		return 품목;
	}

	public void set품목(String 품목) {
		this.품목 = 품목;
	}

	public int get양품수량() {
		return 양품수량;
	}

	public void set양품수량(int 양품수량) {
		this.양품수량 = 양품수량;
	}

	public String get양품재고위치() {
		return 양품재고위치;
	}

	public void set양품재고위치(String 양품재고위치) {
		this.양품재고위치 = 양품재고위치;
	}

	public int get불량수량() {
		return 불량수량;
	}

	public void set불량수량(int 불량수량) {
		this.불량수량 = 불량수량;
	}

	public String get불량재고위치() {
		return 불량재고위치;
	}

	public void set불량재고위치(String 불량재고위치) {
		this.불량재고위치 = 불량재고위치;
	}
}
