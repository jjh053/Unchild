package test.jsp;

public class Mes_DTO {
	int mesId;
	String mesName;
	String mesGrade;
	String mesContent;
	int mesPrice;
	int gCount;
	String gLoc;
	int bCount;
	String bLoc;
	
	
	public int getMesId() {
		return mesId;
	}
	public void setMesId(int mesId) {
		this.mesId = mesId;
	}
	public String getMesName() {
		return mesName;
	}
	public void setMesName(String mesName) {
		this.mesName = mesName;
	}
	public String getMesGrade() {
		return mesGrade;
	}
	public void setMesGrade(String mesGrade) {
		this.mesGrade = mesGrade;
	}
	public String getMesContent() {
		return mesContent;
	}
	public void setMesContent(String mesContent) {
		this.mesContent = mesContent;
	}
	public int getMesPrice() {
		return mesPrice;
	}
	public void setMesPrice(int mesPrice) {
		this.mesPrice = mesPrice;
	}
	public int getGCount() {
		return gCount;
	}
	public void setGCount(int gCount) {
		this.gCount = gCount;
	}
	public String getGLoc() {
		return gLoc;
	}
	public void setGLoc(String gLoc) {
		this.gLoc = gLoc;
	}
	public int getBCount() {
		return bCount;
	}
	public void setBCount(int bCount) {
		this.bCount = bCount;
	}
	public String getBLoc() {
		return bLoc;
	}
	public void setBLoc(String bLoc) {
		this.bLoc = bLoc;
	}
	
	

}
