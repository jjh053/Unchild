package fpm.jsp;

public class Fpm_DTO {
	
	int 일일번호;
	String 일일등급;
	int 일일완제품;
	int 일일불량품;
	
	int 주간번호;
	String 주간등급;
	int 주간완제품;
	public int get일일번호() {
		return 일일번호;
	}
	public void set일일번호(int 일일번호) {
		this.일일번호 = 일일번호;
	}
	public String get일일등급() {
		return 일일등급;
	}
	public void set일일등급(String 일일등급) {
		this.일일등급 = 일일등급;
	}
	public int get일일완제품() {
		return 일일완제품;
	}
	public void set일일완제품(int 일일완제품) {
		this.일일완제품 = 일일완제품;
	}
	public int get일일불량품() {
		return 일일불량품;
	}
	public void set일일불량품(int 일일불량품) {
		this.일일불량품 = 일일불량품;
	}
	public int get주간번호() {
		return 주간번호;
	}
	public void set주간번호(int 주간번호) {
		this.주간번호 = 주간번호;
	}
	public String get주간등급() {
		return 주간등급;
	}
	public void set주간등급(String 주간등급) {
		this.주간등급 = 주간등급;
	}
	public int get주간완제품() {
		return 주간완제품;
	}
	public void set주간완제품(int 주간완제품) {
		this.주간완제품 = 주간완제품;
	}
	public int get주간불량품() {
		return 주간불량품;
	}
	public void set주간불량품(int 주간불량품) {
		this.주간불량품 = 주간불량품;
	}
	public int get월간번호() {
		return 월간번호;
	}
	public void set월간번호(int 월간번호) {
		this.월간번호 = 월간번호;
	}
	public String get월간등급() {
		return 월간등급;
	}
	public void set월간등급(String 월간등급) {
		this.월간등급 = 월간등급;
	}
	public int get월간완제품() {
		return 월간완제품;
	}
	public void set월간완제품(int 월간완제품) {
		this.월간완제품 = 월간완제품;
	}
	public int get월간불량품() {
		return 월간불량품;
	}
	public void set월간불량품(int 월간불량품) {
		this.월간불량품 = 월간불량품;
	}
	int 주간불량품;
	
	int 월간번호;
	String 월간등급;
	int 월간완제품;
	int 월간불량품;
	
	
	
}
